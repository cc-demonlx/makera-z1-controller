const $ = id => document.getElementById(id);
let token, state, requestBusy = false, submitDialog, toastTimer;
const labels = { Idle:'空闲', Run:'运行中', Home:'回零中', Homing:'回零中', Alarm:'告警', Hold:'暂停', Wait:'等待', Tool:'换刀中' };
const fmt = value => Number.isFinite(value) ? value.toFixed(3) : '—';
function toast(text, error = false) {
  clearTimeout(toastTimer); $('toast').textContent = text; $('toast').className = error ? 'error' : ''; $('toast').hidden = false;
  toastTimer = setTimeout(() => { $('toast').hidden = true; }, 5500);
}
async function api(path, body) {
  const res = await fetch(`/api/${path}`, { method: body === undefined ? 'GET' : 'POST', headers: { 'X-Session-Token': token, ...(body === undefined ? {} : {'Content-Type':'application/json'}) }, ...(body === undefined ? {} : {body:JSON.stringify(body)}) });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || '请求失败');
  return data;
}
async function refresh() { state = await api('state'); render(); }
async function run(path, body = {}) {
  if (requestBusy) return;
  requestBusy = true; if (state) render();
  try { const result = await api(path, body); if (result.message) toast(result.message); }
  catch (e) { toast(e.message, true); }
  finally { requestBusy = false; await refresh().catch(() => offline()); }
}
function offline() {
  if (state) { state.connected = false; state.armed = false; state.status = null; state.statusAge = null; state.homed = false; state.estop = null; state.modal = null; render(); }
  $('freshness').textContent = '本地服务已停止，请重新启动控制台';
}
function render() {
  const s = state, status = s.status, fields = status?.fields || {};
  const stale = !status || s.statusAge > 2000;
  const idle = status?.state === 'Idle', editable = !requestBusy && s.connected && s.armed && !s.operation && !stale && !s.uncertain;
  $('connectionBadge').textContent = s.demo && s.connected ? '模拟模式' : s.connecting ? '连接中…' : s.connected ? '已连接' : '未连接';
  $('connectionBadge').className = `badge ${s.connected ? s.demo ? 'demo' : 'connected' : ''}`;
  $('model').textContent = s.model ? `${s.model.name} · ${s.address}` : '等待识别';
  $('connect').disabled = s.connected || s.connecting || requestBusy;
  $('demo').disabled = s.connected || s.connecting || requestBusy;
  $('disconnect').disabled = !s.connected && !s.connecting;
  $('host').disabled = s.connected || s.connecting;
  $('port').disabled = s.connected || s.connecting;
  const discovery = s.discovery || {}, devices = discovery.devices || [];
  $('discover').disabled = s.connected || s.connecting || requestBusy || discovery.scanning;
  $('discover').textContent = discovery.scanning ? '搜索中…' : '搜索机器';
  $('discoveryStatus').textContent = discovery.error || (discovery.scanning
    ? `正在搜索 · 已发现 ${devices.length} 台，约 10 秒后结束`
    : discovery.finishedAt ? devices.length ? `发现 ${devices.length} 台 · 点选设备填入地址，再点击连接`
      : '未收到设备广播。请确认机器开机且在同一网络；若 Studio 正在搜索，请关闭后重试。'
    : '电脑与机器连接同一个 Wi-Fi，即可搜索。');
  const discoveryList = $('discoveryList');
  const discoveryKey = JSON.stringify([devices.map(d => [d.name, d.host, d.port]), s.connected, s.connecting, requestBusy]);
  if (discoveryList.dataset.key !== discoveryKey) {
    discoveryList.replaceChildren(...devices.map(device => {
      const button = document.createElement('button'); button.type = 'button';
      button.disabled = s.connected || s.connecting || requestBusy;
      const name = document.createElement('strong'), address = document.createElement('span');
      name.textContent = device.name; address.textContent = `${device.host}:${device.port}`;
      button.append(name, address);
      button.onclick = () => { $('host').value = device.host; $('port').value = device.port; toast('地址已填入，点击“连接”进入只读模式'); };
      return button;
    }));
    discoveryList.dataset.key = discoveryKey;
  }
  discoveryList.hidden = !devices.length;
  $('demoNotice').hidden = !s.demo || !s.connected;
  $('machineState').textContent = `状态 ${status ? labels[status.state] || status.state : '—'}`;
  $('homed').textContent = `回零 ${s.connected ? s.homed ? '已确认' : '未确认' : '—'}`;
  $('units').textContent = `单位 ${s.modal?.units === 'mm' ? '毫米' : s.modal?.units === 'inch' ? '英寸' : '—'}`;
  $('estop').textContent = `急停 ${s.estop === false ? '未触发' : s.estop === true ? '已触发' : '—'}`;
  $('freshness').textContent = status ? stale ? '状态已过期，操作已锁定' : `状态已更新 · ${(s.statusAge / 1000).toFixed(1)} 秒前` : '等待机器状态';
  for (const [i, axis] of [...'XYZA'].entries()) {
    $(`work${axis}`).textContent = fmt(status?.work?.[i]);
    $(`machine${axis}`).textContent = fmt(status?.machine?.[i]);
  }
  const metric = key => fields[key]?.split(',')[0] ?? '—';
  $('feed').textContent = metric('F'); $('spindle').textContent = metric('S'); $('laser').textContent = fields.L?.split(',')[3] ?? '—';
  const tool = fields.T?.split(',');
  const toolNames = {'-1':'空刀','0':'探针','8888':'激光','9999':'3D 探针'};
  $('tool').textContent = tool ? `${toolNames[tool[0]] || tool[0]} / ${tool[1] ?? '—'}` : '—';
  document.querySelectorAll('.jog').forEach(el => { el.disabled = !(editable && idle && s.homed && (el.dataset.axis !== 'A' || s.profile.rotary)); });
  $('home').disabled = !(editable && idle);
  $('unlock').disabled = !(editable && ['Idle','Alarm'].includes(status?.state));
  $('reset').disabled = $('unlock').disabled;
  for (const id of ['origin','quick','probe3d','autoprobe']) $(id).disabled = !(editable && idle && s.homed);
  $('quick').disabled ||= !s.profile.presets;
  $('probe3d').disabled ||= !s.profile.probe;
  $('autoprobe').disabled ||= !s.profile.probe;
  $('arm').checked = s.armed;
  $('arm').disabled = requestBusy || !s.connected || stale || s.estop !== false || !s.model || s.modal?.units !== 'mm' || !!s.operation || s.uncertain || !['Idle','Alarm'].includes(status?.state);
  $('armLabel').textContent = s.armed ? '操作已启用' : '只读模式';
  $('operation').textContent = s.uncertain ? '结果未知，请核查机器后重新连接。' : s.operation ? `${s.operation.label} · ${s.operation.acknowledged ? '等待实际完成' : '等待响应'}` : s.armed ? '每次点击执行一次有限步长移动。' : '启用操作前，请确认机器周围可安全移动。';
  $('physicalStop').hidden = !s.connected || s.demo || (!s.armed && !s.operation && !s.uncertain);
  $('settings').disabled = requestBusy || s.armed || !!s.operation;
  $('logCount').textContent = `${s.logs.length} 条`;
  const list = $('logList');
  const atBottom = list.scrollTop + list.clientHeight >= list.scrollHeight - 30;
  if (list.dataset.last !== String(s.logs.at(-1)?.id)) {
    list.replaceChildren(...s.logs.map(log => { const li = document.createElement('li'); li.className = log.kind; li.textContent = `${new Date(log.at).toLocaleTimeString('zh-CN',{hour12:false})}  ${log.message}`; return li; }));
    list.dataset.last = String(s.logs.at(-1)?.id);
    if (atBottom) list.scrollTop = list.scrollHeight;
  }
}
$('connectionForm').addEventListener('submit', e => { e.preventDefault(); run('connect', {host:$('host').value.trim(),port:Number($('port').value)}); });
$('demo').onclick = () => run('demo');
$('discover').onclick = () => run('discover');
$('disconnect').onclick = () => run('disconnect');
$('arm').onchange = () => run('arm', {enabled:$('arm').checked});
document.querySelectorAll('.jog').forEach(el => { el.onclick = () => run('action', {action:'jog',data:{axis:el.dataset.axis,distance:Number($(el.dataset.axis === 'A' ? 'aStep' : el.dataset.axis === 'Z' ? 'zStep' : 'xyStep').value) * Number(el.dataset.sign)}}); });
function closeDialog() { $('dialog').close(); }
$('closeDialog').onclick = closeDialog; $('cancelDialog').onclick = closeDialog;
$('dialogForm').onsubmit = async e => {
  e.preventDefault(); $('dialogError').textContent = ''; $('dialogSubmit').disabled = true;
  try { await submitDialog(); closeDialog(); await refresh(); }
  catch (err) { $('dialogError').textContent = err.message; }
  finally { $('dialogSubmit').disabled = false; }
};
function dialog(title, content, submit, label = '确认执行') {
  $('dialogTitle').textContent = title; $('dialogContent').innerHTML = content; $('dialogError').textContent = '';
  $('dialogSubmit').textContent = label; submitDialog = submit; $('dialog').showModal();
}
const field = (id,label,value,min,max,step = '0.1') => `<label>${label}<input id="${id}" type="number" value="${value}" min="${min}" max="${max}" step="${step}" required></label>`;
const number = id => Number($(id).value);
const action = (name, data = {}) => api('action', {action:name,data});
$('home').onclick = () => dialog('回机械原点','<p>机器将移动到机械参考位置。请确认刀具、工件和附件不会阻挡回零路径。</p>', () => action('home'), '开始回零');
$('unlock').onclick = () => dialog('解除告警','<p>请先排除机器告警原因。解锁后不会自动继续上次动作。</p>', () => action('unlock'), '解锁');
$('reset').onclick = () => dialog('重启控制器','<p>机器控制器将重启，当前连接会断开。重启完成后需要重新连接。</p>', () => action('reset'), '重启');
$('origin').onclick = () => {
  dialog('设置工作原点','<p>将选中轴的当前位置设为工作零点。</p><div class="checkboxes">' + [...'XYZA'].filter(a => a !== 'A' || state.profile.rotary).map(a => `<label class="check-row"><input id="zero${a}" type="checkbox" ${a === 'X' || a === 'Y' ? 'checked' : ''}>${a}</label>`).join('') + '</div>', () => action('origin', {axes:[...'XYZA'].filter(a => $(`zero${a}`)?.checked)}), '设置零点');
};
$('quick').onclick = () => dialog('快速移动','<p>使用机器已配置的抬刀高度和预设位置。</p><label>目标位置<select id="preset"><option value="1">避让位置</option><option value="2">工作原点</option><option value="3">定位点 1</option><option value="4">定位点 2</option></select></label>', () => action('quick', {preset:number('preset')}), '开始移动');
$('probe3d').onclick = () => dialog('3D 探测','<p>探针应已校准，并处于所选探测方式的正确起始位置。首次实机探测需在机器旁验证。</p><label>探测方式<select id="probeMode">' + ['外角 X+ / Y+','外角 X− / Y+','外角 X− / Y−','外角 X+ / Y−','内角 X+ / Y+','内角 X− / Y+','内角 X− / Y−','内角 X+ / Y−','内部口袋','外部口袋'].map((x,i) => `<option value="${i+1}">${x}</option>`).join('') + '</select></label><div class="form-grid">' + field('probeX','X 范围 · mm',20,.1,100) + field('probeY','Y 范围 · mm',20,.1,100) + field('probeZ','Z 距离 · mm',2,.1,30) + field('probeDiameter','探针直径 · mm',2,.1,20) + '</div>', () => action('probe3d', {mode:number('probeMode'),x:number('probeX'),y:number('probeY'),z:number('probeZ'),diameter:number('probeDiameter')}), '开始探测');
$('autoprobe').onclick = () => {
  dialog('自动 Z 探测 / 找平','<p>使用机器固件内置流程。请确认探针、工件起点与找平范围。</p><div class="form-grid">' + field('autoX','作业起点 X · mm',0,-1000,1000) + field('autoY','作业起点 Y · mm',0,-1000,1000) + field('offsetX','探测点 X 偏移 · mm',0,-100,100) + field('offsetY','探测点 Y 偏移 · mm',0,-100,100) + '</div><label class="check-row"><input type="checkbox" id="leveling">同时进行网格找平</label><div id="gridFields" class="form-grid" hidden>' + field('gridWidth','找平宽度 · mm',50,1,200) + field('gridHeight','找平高度 · mm',50,1,200) + field('gridX','X 网格数',3,2,15,1) + field('gridY','Y 网格数',3,2,15,1) + field('gridZ','抬升高度 · mm',5,1,30) + '</div>', () => action('autoprobe', {x:number('autoX'),y:number('autoY'),offsetX:number('offsetX'),offsetY:number('offsetY'),leveling:$('leveling').checked,width:number('gridWidth'),height:number('gridHeight'),nx:number('gridX'),ny:number('gridY'),clearance:number('gridZ')}), '开始探测');
  $('leveling').onchange = () => { $('gridFields').hidden = !$('leveling').checked; };
};
$('settings').onclick = () => {
  const profile = state.profile;
  dialog('机器设置','<p>' + (state.machineSettings ? 'XYZ 范围已从这台机器读取，每次连接会重新读取。' : '本次连接尚未自动读取范围。请依据实际机器配置填写。') + ' 附件与探针条件需现场核对。保存仅调整控制台，不修改机器固件。</p><div class="limits range-head"><span>轴</span><span>机器坐标最小值</span><span>机器坐标最大值</span></div>' + [...'XYZA'].map(a => `<div class="limits"><span>${a}</span><input id="min${a}" type="number" step="any" placeholder="未设置" aria-label="${a} 轴最小机器坐标"><input id="max${a}" type="number" step="any" placeholder="未设置" aria-label="${a} 轴最大机器坐标"></div>`).join('') + '<label class="check-row"><input type="checkbox" id="rotary">第四轴已安装并配置</label><label class="check-row"><input type="checkbox" id="presets">已核对机器抬刀高度与预设位置</label><label class="check-row"><input type="checkbox" id="probe">探针已安装、校准，起始条件已核对</label>', async () => {
    const limits = {};
    for (const a of 'XYZA') {
      if ($(`min${a}`).value === '' && $(`max${a}`).value === '') continue;
      if ($(`min${a}`).value === '' || $(`max${a}`).value === '') throw new Error(`${a} 轴最小值和最大值需同时填写`);
      limits[a] = [number(`min${a}`),number(`max${a}`)];
    }
    await api('profile', {limits,rotary:$('rotary').checked,presets:$('presets').checked,probe:$('probe').checked});
  }, '保存设置');
  for (const a of 'XYZA') {
    if (profile.limits[a]) { $(`min${a}`).value = profile.limits[a][0]; $(`max${a}`).value = profile.limits[a][1]; }
  }
  for (const name of ['rotary','presets','probe']) $(name).checked = profile[name];
};
$('export').onclick = async () => {
  let recording;
  try { recording = await api('recording'); } catch (e) { toast(e.message,true); return; }
  const blob = new Blob([JSON.stringify(recording,null,2)],{type:'application/json'});
  const url = URL.createObjectURL(blob), a = document.createElement('a'); a.href = url; a.download = 'z1-control-log.json'; a.click(); URL.revokeObjectURL(url);
};
try {
  const session = await fetch('/api/session').then(r => r.json()); token = session.token;
  await refresh();
  setInterval(() => refresh().catch(offline), 500);
} catch (e) { toast(`本地服务连接失败：${e.message}`,true); }
