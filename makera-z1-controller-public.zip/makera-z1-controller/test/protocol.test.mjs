import test from 'node:test';
import assert from 'node:assert/strict';
import { crc16, frame, FrameParser } from '../lib/protocol.mjs';
import { parseStatus, parseModal, parseHomed } from '../lib/status.mjs';

test('CRC standard vector and independent status-query byte fixture', () => {
  assert.equal(crc16(Buffer.from('123456789')), 0x31c3);
  // CRC verified separately with Python binascii.crc_hqx, not this encoder.
  assert.equal(frame(0xa1, '?').toString('hex'), '86680004a13f353355aa');
});
test('parser preserves split headers and handles every split of a known frame', () => {
  const data = frame(0x81, '<Idle|MPos:1,2,3|WPos:0,0,0>');
  for (let split = 0; split <= data.length; split++) {
    const parser = new FrameParser();
    const packets = [...parser.feed(data.subarray(0, split)), ...parser.feed(data.subarray(split))];
    assert.equal(packets.length, 1); assert.equal(packets[0].type, 0x81);
    assert.equal(packets[0].payload.toString(), '<Idle|MPos:1,2,3|WPos:0,0,0>');
  }
});
test('rejects corruption and resynchronizes to next coalesced packet', () => {
  const corrupt = frame(0x90, 'bad\n'); corrupt[5] ^= 1;
  const parser = new FrameParser();
  const packets = parser.feed(Buffer.concat([Buffer.from([0, 1, 0x86]), corrupt, frame(0x90, 'ok\n'), frame(0x82, '{I:0}')]));
  assert.equal(packets.length, 2); assert.ok(parser.errors >= 1);
  assert.equal(packets[0].payload.toString(), 'ok\n');
});
test('malformed lengths and invalid tails are not delivered', () => {
  const malformed = Buffer.from('86680000a155aa', 'hex');
  const badTail = frame(0x90, 'ok\n'); badTail[badTail.length - 1] = 0;
  const parser = new FrameParser();
  assert.deepEqual(parser.feed(Buffer.concat([malformed, badTail])), []);
});
test('strict status grammar never substitutes missing/invalid coordinates', () => {
  const good = parseStatus('<Idle|MPos:-1,2.5,3,90|WPos:0,0,0,0|C:4,0,0,1>\n');
  assert.deepEqual(good.machine, [-1,2.5,3,90]); assert.equal(good.fields.C, '4,0,0,1');
  for (const bad of ['<Idle|MPos:0,0,0>', '<Idle|MPos:NaN,0,0|WPos:0,0,0>', '<Idle|MPos:0,0,0|WPos:0,,0>', '<Idle|MPos:0,0,0|MPos:1,1,1|WPos:0,0,0>', '<Idle|MPos:0,0,0|WPos:0,0,0>garbage']) assert.equal(parseStatus(bad), null);
});
test('homing query rejects missing/duplicate XYZ and modal rejects contradictions', () => {
  assert.deepEqual(parseHomed('X:1 Y:1 Z:0 \nok\n'), {X:true,Y:true,Z:false});
  assert.equal(parseHomed('X:1 Y:1'), null); assert.equal(parseHomed('X:1 X:0 Y:1 Z:1'), null);
  assert.deepEqual(parseModal('[G0 G21 G90 M5]'), {units:'mm',absolute:true});
  assert.equal(parseModal('[G20 G21 G90]'), null); assert.equal(parseModal('[G21 G90 G91]'), null);
});
