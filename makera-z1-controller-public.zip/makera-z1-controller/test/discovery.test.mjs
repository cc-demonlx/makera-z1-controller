import test from 'node:test';
import assert from 'node:assert/strict';
import dgram from 'node:dgram';
import { setTimeout as delay } from 'node:timers/promises';
import { Discovery, parseAnnouncement } from '../lib/discovery.mjs';

test('discovery parses Studio CSV and rejects malformed or non-LAN endpoints', () => {
  const parse = text => parseAnnouncement(Buffer.from(text));
  assert.deepEqual(parse('MK_Makera_Z1_EXAMPLE,192.168.50.10,2222,1,extra\0'), {
    name: 'MK_Makera_Z1_EXAMPLE', host: '192.168.50.10', port: 2222, announcedFlag: '1', extra: 'extra',
  });
  assert.equal(parse('我的 Z1,10.0.0.10,2222,0').name, '我的 Z1');
  for (const input of ['QUERY', 'Z1,192.168.1.1,2222', 'Z1,8.8.8.8,2222,1', 'Z1,127.0.0.1,2222,1',
    'Z1,192.168.1.255,2222,1', 'Z1,192.168.1.10,0,1', 'Z1,192.168.1.10,65536,1',
    'Z1,192.168.1.10,2222junk,1', 'Z1,192.168.1.10,2222,unknown', ',192.168.1.10,2222,1',
    'Z1\n,192.168.1.10,2222,1', 'x'.repeat(2049)]) assert.equal(parse(input), null, input);
  assert.equal(parseAnnouncement(Buffer.from([0xff, 0xfe])), null);
});

test('UDP listener deduplicates announcements, times out and releases its port', async t => {
  // Loopback delivery is allowed only in this test; production accepts LAN senders.
  const discovery = new Discovery({ port: 0, host: '127.0.0.1', duration: 250, acceptSource: source => source === '127.0.0.1' });
  t.after(() => discovery.stop());
  await discovery.start();
  await assert.rejects(discovery.start(), /正在搜索/);
  const port = discovery.active.socket.address().port;
  const sender = dgram.createSocket('udp4'); t.after(() => sender.close());
  const send = text => new Promise((resolve, reject) => sender.send(text, port, '127.0.0.1', error => error ? reject(error) : resolve()));
  await send('QUERY');
  await send('Z1,192.168.50.10,2222,1');
  await send('Z1 renamed,192.168.50.10,2222,0');
  for (let i = 0; i < 40 && discovery.snapshot().devices[0]?.name !== 'Z1 renamed'; i++) await delay(5);
  const state = discovery.snapshot();
  assert.equal(state.scanning, true);
  assert.equal(state.devices.length, 1);
  assert.equal(state.devices[0].name, 'Z1 renamed');
  assert.equal(state.devices[0].source, '127.0.0.1');
  // Snapshot consumers cannot change the saved endpoint.
  state.devices[0].host = '8.8.8.8';
  assert.equal(discovery.snapshot().devices[0].host, '192.168.50.10');
  for (let i = 0; i < 80 && discovery.snapshot().scanning; i++) await delay(5);
  assert.equal(discovery.snapshot().scanning, false);
  assert.ok(discovery.snapshot().finishedAt);
  const probe = dgram.createSocket('udp4'); t.after(() => probe.close());
  await new Promise((resolve, reject) => { probe.once('error', reject); probe.bind(port, '127.0.0.1', resolve); });
});

test('discovery rejects non-LAN sources and supports cancellation and a fresh search', async t => {
  const discovery = new Discovery({ port: 0, host: '127.0.0.1' }); t.after(() => discovery.stop());
  await discovery.start();
  discovery.active.socket.emit('message', Buffer.from('Z1,192.168.50.10,2222,1'), { address: '8.8.8.8' });
  assert.equal(discovery.snapshot().devices.length, 0);
  discovery.active.socket.emit('message', Buffer.from('Z1,192.168.50.10,2222,1'), { address: '192.168.50.10' });
  assert.equal(discovery.snapshot().devices.length, 1);
  discovery.stop();
  assert.equal(discovery.snapshot().scanning, false);
  await discovery.start();
  assert.equal(discovery.snapshot().devices.length, 0);
});

test('occupied discovery port returns an actionable error without staying active', async t => {
  const blocker = dgram.createSocket('udp4'); t.after(() => blocker.close());
  await new Promise((resolve, reject) => { blocker.once('error', reject); blocker.bind(0, '127.0.0.1', resolve); });
  const discovery = new Discovery({ port: blocker.address().port, host: '127.0.0.1' }); t.after(() => discovery.stop());
  await assert.rejects(discovery.start(), /搜索端口被占用/);
  assert.equal(discovery.snapshot().scanning, false);
  assert.equal(discovery.active, null);
});
