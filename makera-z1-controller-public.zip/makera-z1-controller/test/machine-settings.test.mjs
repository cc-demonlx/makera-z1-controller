import test from 'node:test';
import assert from 'node:assert/strict';
import { parseMachineLimits } from '../lib/machine-settings.mjs';

const report = 'Soft endstops are Disabled,X min = -200.000,X max = -1.000,Y min = -200.000,Y max = -1.000,Z min = -100.000,Z max = -1.000';
test('machine settings use explicit reported min/max, preserving firmware enforcement state', () => {
  const parsed = parseMachineLimits(report + '\nok\n');
  assert.deepEqual(parsed.limits, { X: [-200, -1], Y: [-200, -1], Z: [-100, -1] });
  assert.equal(parsed.firmwareSoftEndstopsEnabled, false);
  assert.equal(parseMachineLimits(report.replace('Disabled', 'Enabled')).firmwareSoftEndstopsEnabled, true);
});
test('unhomed, disabled, duplicate, incomplete and inverted bounds cannot configure movement', () => {
  for (const bad of [report + ',X axis is not homed', report.replace('X min = -200.000', 'X min is disabled'),
    report + ',X min = -200.000', report + '\n' + report, report.replace(',Z max = -1.000', ''),
    report.replace('X min = -200.000', 'X min = 0'), 'ok\n']) assert.throws(() => parseMachineLimits(bad));
});
