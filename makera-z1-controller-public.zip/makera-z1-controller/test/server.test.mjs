import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp, privateIPv4 } from '../server.mjs';
import { Discovery } from '../lib/discovery.mjs';
test('real targets restricted to explicit LAN IP addresses', () => {
  for (const ip of ['192.168.1.20','10.1.0.2','172.16.2.3','169.254.1.2']) assert.equal(privateIPv4(ip),true);
  for (const ip of ['localhost','127.0.0.1','0.0.0.0','8.8.8.8','192.168.1.255','192.168.1.0','example.com','::1','192.168.999.1']) assert.equal(privateIPv4(ip),false);
});
test('discovery API needs a session and never connects or arms a machine', async t => {
  const discovery = new Discovery({ port: 0, host: '127.0.0.1', duration: 100 });
  const app = await createApp({ discovery }); t.after(() => app.close());
  const post = token => fetch(app.origin + '/api/discover', { method: 'POST', headers: {
    Origin: app.origin, 'Content-Type': 'application/json', 'X-Session-Token': token,
  }, body: '{}' });
  assert.equal((await post('wrong')).status, 403);
  assert.equal(discovery.active, null);
  assert.equal((await post(app.token)).status, 200);
  const state = await (await fetch(app.origin + '/api/state', { headers: { 'X-Session-Token': app.token } })).json();
  assert.equal(state.discovery.scanning, true);
  assert.equal(state.connected, false);
  assert.equal(state.armed, false);
});
test('HTTP API enforces local host, origin, token, read-only default and recording', async t => {
  const app=await createApp(); t.after(() => app.close());
  const get = path => fetch(app.origin+path,{headers:{'X-Session-Token':app.token}});
  const post = (path,body,extra={}) => fetch(app.origin+path,{method:'POST',headers:{'Content-Type':'application/json','Origin':app.origin,'X-Session-Token':app.token,...extra},body:JSON.stringify(body)});
  assert.equal((await fetch(app.origin+'/')).status,200);
  assert.equal((await fetch(app.origin+'/api/state')).status,403);
  assert.equal((await post('/api/arm',{enabled:true},{Origin:'https://evil.test'})).status,403);
  assert.equal((await post('/api/demo',{}, {'X-Session-Token':'bad'})).status,403);
  const wrongHost = await new Promise((resolve,reject) => { const req=http.get(app.origin+'/api/session',{headers:{Host:'evil.test'}},res=>{res.resume();resolve(res.statusCode);});req.on('error',reject); });
  assert.equal(wrongHost,403);
  assert.equal((await post('/api/connect',{host:'127.0.0.1',port:1})).status,400);
  assert.equal((await post('/api/demo',{})).status,200);
  const state=await (await get('/api/state')).json(); assert.equal(state.connected,true); assert.equal(state.armed,false); assert.equal(state.demo,true);
  assert.equal((await post('/api/action',{action:'home'})).status,400);
  const recording=await (await get('/api/recording')).json(); assert.ok(recording.packets.some(x=>x.direction==='rx'));
  assert.equal((await post('/api/disconnect',{})).status,200);
});
