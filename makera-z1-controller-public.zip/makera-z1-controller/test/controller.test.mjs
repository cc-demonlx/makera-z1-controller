import test from 'node:test';
import assert from 'node:assert/strict';
import { Controller } from '../lib/controller.mjs';
import { startSimulator } from '../lib/simulator.mjs';
import { TYPES } from '../lib/protocol.mjs';
import { buildAction } from '../lib/actions.mjs';
const wait = async fn => { const end = Date.now() + 6500; while (!fn()) { if (Date.now() > end) throw new Error('Condition timed out'); await new Promise(r => setTimeout(r, 30)); } };
function ready(now = Date.now()) {
  const c = new Controller({now:() => now});
  c.connected = true; c.statusAt = now; c.diagAt = now; c.homedAt = now;
  c.model = {name:'Z1'}; c.modal = {units:'mm',absolute:true}; c.estop = false; c.homed = true;
  c.status = {state:'Idle',machine:[-10,-10,-10,0],work:[0,0,0,0]};
  c.profile = {rotary:false,probe:false,presets:false,limits:{X:[-100,0]}};
  return c;
}
test('server-side gates reject read-only, stale, estop, unhomed and busy motion', async () => {
  for (const [edit, pattern] of [
    [c => {}, /只读/], [c => {c.armed=true;c.statusAt-=3000;}, /新鲜/],
    [c => {c.armed=true;c.estop=null;}, /急停/], [c => {c.armed=true;c.homed=false;}, /回零/],
    [c => {c.armed=true;c.status.state='Run';}, /空闲/], [c => {c.armed=true;c.uncertain=true;}, /结果未知/],
  ]) { const c = ready(); edit(c); await assert.rejects(c.action('jog',{axis:'X',distance:1}),pattern); }
});
test('bounds, finite numbers, attachments and command injection are rejected', () => {
  const c = ready();
  for (const data of [{axis:'X\nG0Z100',distance:1},{axis:'X',distance:NaN},{axis:'X',distance:Infinity},{axis:'X',distance:11},{axis:'A',distance:90}]) assert.throws(() => buildAction('jog',data,c.status,c.profile));
  assert.throws(() => buildAction('jog',{axis:'X',distance:10}, {...c.status,machine:[-1,-10,-10]}, c.profile), /超出/);
  assert.throws(() => buildAction('probe3d',{mode:1,x:1,y:1,z:1,diameter:1},c.status,c.profile), /探针/);
  assert.throws(() => buildAction('origin',{axes:['X','X']},c.status,c.profile));
});
test('ACK alone cannot complete motion; tiny jog cannot complete at its starting position', () => {
  const c = ready(); c.armed = true;
  c.operation = {seq:0, acknowledged:true, target:{index:0,value:-9.999,tolerance:.00025}, startedAt:Date.now()};
  c.statusSeq = 1; c.checkOperation(); assert.ok(c.operation);
});
test('read-only model query accepts a complete typed line without ok, never a bare ok or partial line', async () => {
  const c = new Controller({ackTimeout:1000}); c.send = () => {};
  const result = c.command('model');
  c.receive({type:TYPES.INFO,payload:Buffer.from('ok\r\n')}); assert.ok(c.pending);
  c.receive({type:TYPES.INFO,payload:Buffer.from('model = Z1, 3, 1, 0, Idle')}); assert.ok(c.pending);
  c.receive({type:TYPES.INFO,payload:Buffer.from('\n')});
  assert.match(await result, /model = Z1/); assert.equal(c.pending,null); assert.equal(c.uncertain,false);
});
test('model response exception never acknowledges a motion command', async () => {
  const c = new Controller({ackTimeout:1000}); c.send = () => {};
  const result = c.command('G91 G0 X-0.1');
  c.receive({type:TYPES.INFO,payload:Buffer.from('model = Z1, 3, 1, 0, Idle\n')}); assert.ok(c.pending);
  c.receive({type:TYPES.INFO,payload:Buffer.from('not ok\n')}); assert.ok(c.pending);
  c.receive({type:TYPES.INFO,payload:Buffer.from('ok\n')}); await result; assert.equal(c.pending,null);
});
test('machine limits auto-fill only from a complete read-only report covering the current position', async () => {
  const c = ready();
  c.command = async text => { assert.equal(text,'M211'); return 'Soft endstops are Enabled,X min = -207.000,X max = -1.000,Y min = -206.000,Y max = -1.000,Z min = -102.000,Z max = -1.000\nok\n'; };
  await c.readMachineSettings();
  assert.deepEqual(c.profile.limits,{X:[-207,-1],Y:[-206,-1],Z:[-102,-1]});
  assert.equal(c.armed,false); assert.equal(c.profile.probe,false);
  assert.equal(c.machineSettings.firmwareSoftEndstopsEnabled,true);
  c.status.machine[0] = 0;
  await assert.rejects(c.readMachineSettings(), /当前坐标/);
  c.armed = true; await assert.rejects(c.readMachineSettings(), /只读/);
});
test('curly-brace diagnose I gates stop and invalid status invalidates operation', () => {
  const c = ready();
  c.receive({type:TYPES.DIAGNOSE,payload:Buffer.from('{P:0,0|I:0}')}); assert.equal(c.estop,false);
  c.armed=true; c.receive({type:TYPES.DIAGNOSE,payload:Buffer.from('{I:1}')}); assert.equal(c.armed,false);
  c.operation={label:'move'}; c.receive({type:TYPES.STATUS,payload:Buffer.from('<Idle|MPos:0,0,0>')});
  assert.equal(c.operation,null); assert.equal(c.uncertain,true); assert.equal(c.status,null);
});
test('persistent Alarm permits explicit unlock without becoming a motion permission', () => {
  const c = ready(); c.status.state='Alarm'; c.arm(true);
  c.receive({type:TYPES.STATUS,payload:Buffer.from('<Alarm|MPos:0,0,0|WPos:0,0,0|C:4,0,0,1>')});
  assert.equal(c.armed,true); assert.equal(c.homed,false);
});
test('unknown rotary homing and a changed unit mode fail closed', async () => {
  const c = ready(); c.armed=true; c.profile.rotary=true;
  await assert.rejects(c.action('jog',{axis:'A',distance:1}),/第四轴回零/);
  c.operation={label:'move'};
  c.receive({type:TYPES.STATUS,payload:Buffer.from('<Idle|MPos:0,0,0|WPos:0,0,0|C:4,0,1,1>')});
  assert.equal(c.armed,false); assert.equal(c.operation,null); assert.equal(c.uncertain,true);
});
test('real TCP fixture: read-only connect, homing query, home, jog, mode restore, origin and probe', async t => {
  const mock = await startSimulator(), c = new Controller();
  t.after(async () => {c.disconnect(); await mock.close();});
  await c.connect('127.0.0.1',mock.port,{demo:true});
  assert.equal(c.armed,false); assert.equal(c.estop,false); assert.equal(c.homed,false);
  await assert.rejects(c.action('home'),/只读/);
  c.arm(true); await c.action('home');
  assert.ok(c.operation); await wait(() => !c.operation); assert.equal(c.homed,true);
  await c.action('jog',{axis:'X',distance:-1});
  await wait(() => !c.operation); assert.equal(c.status.machine[0],-2); assert.equal(c.modal.absolute,true);
  assert.ok(mock.received.some(x => x.command==='G90'));
  await c.action('origin',{axes:['X','Y']}); await wait(() => !c.operation); assert.deepEqual(c.status.work.slice(0,2),[0,0]);
  await c.action('probe3d',{mode:1,x:20,y:20,z:2,diameter:2});
  assert.ok(c.operation); await wait(() => !c.operation); assert.equal(c.uncertain,false);
});
test('ACK timeout sends once and blocks further commands without reconnect', async () => {
  const c = ready(); c.armed=true; c.ackTimeout=30;
  let sends=0; c.send=() => sends++;
  await assert.rejects(c.action('jog',{axis:'X',distance:1}),/超时/);
  assert.equal(sends,1); assert.equal(c.armed,false); assert.equal(c.uncertain,true);
  await assert.rejects(c.action('jog',{axis:'X',distance:1}),/结果未知/); assert.equal(sends,1);
});
test('connection loss clears permissions, coordinates and homed; no replay', () => {
  const c = ready(); c.armed=true; c.operation={label:'jog'};
  c.connectionLost(); assert.equal(c.connected,false); assert.equal(c.armed,false); assert.equal(c.homed,false); assert.equal(c.status,null); assert.equal(c.uncertain,true);
});
