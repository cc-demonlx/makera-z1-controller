#!/bin/bash
set -eu
cd -- "$(dirname -- "$0")"
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
if ! command -v node >/dev/null 2>&1; then
  echo "未找到 Node.js。此控制台需要 Node.js 22 或更新版本。"
  read -r -p "按回车退出…"
  exit 1
fi
exec node server.mjs --open
