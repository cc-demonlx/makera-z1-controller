import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { Controller } from './lib/controller.mjs';
import { startSimulator } from './lib/simulator.mjs';
import { Discovery } from './lib/discovery.mjs';
import { privateIPv4 } from './lib/network.mjs';

export { privateIPv4 };
export async function createApp({ port = 0, discovery = new Discovery() } = {}) {
  const controller = new Controller(), simulator = await startSimulator();
  const token = randomBytes(24).toString('hex');
  const assets = { '/': ['index.html','text/html; charset=utf-8'], '/app.js': ['app.js','text/javascript; charset=utf-8'], '/style.css': ['style.css','text/css; charset=utf-8'] };
  let origin;
  const server = http.createServer(async (req, res) => {
    const headers = {
      'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
      'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'",
    };
    const json = (code, body) => { res.writeHead(code, { ...headers, 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(body)); };
    try {
      if (req.headers.host !== new URL(origin).host) return json(403, { error: '无效访问地址' });
      if (req.headers.origin && req.headers.origin !== origin) return json(403, { error: '不允许跨站访问' });
      if (req.headers['sec-fetch-site'] && !['none','same-origin'].includes(req.headers['sec-fetch-site'])) return json(403, { error: '不允许跨站访问' });
      const path = new URL(req.url, origin).pathname;
      if (req.method === 'GET' && assets[path]) {
        const [name, mime] = assets[path];
        res.writeHead(200, { ...headers, 'Content-Type': mime }); res.end(await readFile(new URL(`./public/${name}`, import.meta.url))); return;
      }
      if (req.method === 'GET' && path === '/api/session') return json(200, { token });
      const supplied = Buffer.from(req.headers['x-session-token'] || '');
      if (supplied.length !== token.length || !timingSafeEqual(supplied, Buffer.from(token))) return json(403, { error: '会话无效，请重新打开页面' });
      if (req.method === 'GET' && path === '/api/state') return json(200, { ...controller.snapshot(), discovery: discovery.snapshot() });
      if (req.method === 'GET' && path === '/api/recording') return json(200, { exportedAt: new Date().toISOString(), state: controller.snapshot(), packets: controller.wire });
      if (req.method !== 'POST') return json(404, { error: '页面不存在' });
      if (req.headers.origin !== origin || req.headers['content-type']?.split(';')[0] !== 'application/json') return json(403, { error: '请求来源或格式不正确' });
      let raw = '';
      for await (const chunk of req) { raw += chunk; if (raw.length > 16384) return json(413, { error: '请求过大' }); }
      const body = JSON.parse(raw || '{}');
      if (path === '/api/connect') {
        if (!privateIPv4(body.host)) throw new Error('请输入机器的局域网 IPv4 地址');
        const targetPort = body.port ?? 2222;
        if (!Number.isInteger(targetPort) || targetPort < 1 || targetPort > 65535) throw new Error('端口无效');
        discovery.stop();
        await controller.connect(body.host, targetPort);
      } else if (path === '/api/discover') {
        if (controller.connected || controller.connecting) throw new Error('请先断开当前连接再搜索');
        await discovery.start();
      } else if (path === '/api/demo') {
        if (controller.connected || controller.connecting) throw new Error('请先断开当前连接');
        discovery.stop();
        await controller.connect('127.0.0.1', simulator.port, { demo: true });
      } else if (path === '/api/disconnect') controller.disconnect();
      else if (path === '/api/arm') controller.arm(body.enabled === true);
      else if (path === '/api/profile') controller.configure(body);
      else if (path === '/api/action') return json(200, await controller.action(body.action, body.data));
      else return json(404, { error: '操作不存在' });
      json(200, { ok: true });
    } catch (e) { if (!res.headersSent) json(400, { error: e.message }); else res.end(); }
  });
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(port, '127.0.0.1', resolve); });
  origin = `http://127.0.0.1:${server.address().port}`;
  return { origin, controller, discovery, token, close: async () => { discovery.stop(); controller.disconnect(); server.closeAllConnections(); await Promise.all([new Promise(resolve => server.close(resolve)), simulator.close()]); } };
}
if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const app = await createApp({ port: Number(process.env.Z1_CONTROL_PORT || 0) });
  console.log(`Z1 控制台已启动：${app.origin}\n真实连接默认只读；可先使用模拟模式。按 Control+C 退出。`);
  const stop = async () => { await app.close(); process.exit(0); };
  process.once('SIGINT', stop); process.once('SIGTERM', stop);
  if (process.argv.includes('--open')) {
    const { spawn } = await import('node:child_process');
    const child = spawn(process.platform === 'darwin' ? 'open' : process.platform === 'win32' ? 'cmd' : 'xdg-open', process.platform === 'win32' ? ['/c', 'start', '', app.origin] : [app.origin], { stdio: 'ignore' });
    child.on('error', () => {});
  }
}
